/*
//https://docs.microsoft.com/en-us/aspnet/core/tutorials/signalr?view=aspnetcore-2.2&tabs=visual-studio-code
*/



//dotnet run -p WebApp1.csproj


window.onload = function()
{

    var connection = new signalR.HubConnectionBuilder().withUrl("/chatHub").build();

    //Disable send button until a connection is established. #TODO
    // document.getElementById("sendButton").disabled = true;


    //BEGINNING OF MATT'S CLIENT SIDE CODE.
    //COLORS.
    var canvasDiv = document.getElementById('canvasDiv');
    var colorRed = "#ff0000";
    var colorGreen = "#158b00";
    var colorYellow = "#ffff00";
    var colorBlue = "#0000ff";

    //BUTTONS.
    var curColor = colorRed;
    var clickColor = new Array();
    var clear = document.getElementById("clear");
    var color = document.getElementById("color");
    canvas = document.createElement('canvas');
    context = canvas.getContext("2d");

    //HEIGHT AND WIDTH.
    canvas.setAttribute('width', canvas.width = 1000); //WIDTH.
    canvas.setAttribute('height', canvas.height = 1000); //HEIGHT.
    canvas.setAttribute('id', 'canvas');
    canvasDiv.appendChild(canvas); //ADDING THE CANVAS ON.
    if(typeof G_vmlCanvasManager != 'undefined') {
      canvas = G_vmlCanvasManager.initElement(canvas);
    }
    //END OF THIS SECTION OF MATT'S CLIENT SIDE CODE.


    //SOMETHING THAT MAYYY BE NEEDED IN FUTURE, I DON'T KNOW, I'M NOT SURE.
    connection.start().then(function(){
      // document.getElementById("sendButton").disabled = false;
      //Connection established.

    }).catch(function (err) {
      return console.error(err.toString());
    });


    connection.on("ReceiveMouseDown", function (xPressed, yPressed, newColor) {
      //Getting the inputted stuff and sending it to the server.
      //BIG DEAL.
      paintVal = true;
      addClick(xPressed, yPressed, newColor); //e.pageX - this.offsetLeft, e.pageY - this.offsetTop

      redraw(); //ONCE TOUCHED, IT REPAINTS THE PANEL.
    });
    connection.on("ReceiveMouseMove", function (xPressed, yPressed, newColor) {
      //Getting the inputted stuff and sending it to the server.
      //BIG DEAL.
      addClick(xPressed, yPressed, newColor, true); //e.pageX - this.offsetLeft, e.pageY - this.offsetTop
      redraw(); //ONCE TOUCHED, IT REPAINTS THE PANEL.
    });


    //X, Y COORDINATE OF RECEIVED.
    $('#canvas').mousedown(function(e){
        var mouseX = e.pageX - this.offsetLeft; //X COORD.
        var mouseY = e.pageY - this.offsetTop; //Y COORD.
        paint = true;
        // addClick(e.pageX - this.offsetLeft, e.pageY - this.offsetTop);
        connection.invoke("SendMessage", mouseX, mouseY, curColor)
        .catch(function(err)
        {
            return console.error(err.toString());
        });
        //Taken, put into the "Receive Messages" <?function?> above.
      });
      $('#canvas').mousemove(function(e){
        if(paint){
          // addClick(e.pageX - this.offsetLeft, e.pageY - this.offsetTop, curColor, true);
          // redraw();
          connection.invoke("SendMessage", e.pageX - this.offsetLeft, e.pageY - this.offsetTop, curColor)
          .catch(function(err)
          {
              return console.error(err.toString());
          });
        }
      });



      $('#canvas').mouseup(function(e){
        paint = false;
      });

      $('#canvas').mouseleave(function(e){
        paint = false;
      });





    var clickX = new Array(); //STORED X VALUES OF WHAT'S BEEN CLICKED.
    var clickY = new Array(); //STORED Y VALUES OF WHAT'S BEEN CLICKED.
    var clickDrag = new Array();
    var paint; //WHEN THE PAINTING IS ON.

    //THE FUNCTION THAT WOULD RUN FOR CLICK EVENTS, BUT DOESN'T RUN BY ITSELF.
    function addClick(x, y, color, dragging)
    {
      clickX.push(x);
      clickY.push(y);
      clickDrag.push(dragging);
      clickColor.push(color);
    }

    //CLEAR CANVAS.
    function clearCanvas() {
      clickX = [];
      clickY = [];
      clickDrag = [];
      context.clearRect(0,0, canvas.width, canvas.height);
    }


    //CHANGES THE COLOR THAT THE USER CAN PAINT.
    function changeColor() {
      console.log("Hello, there. This is changeColor.");
      if(color.value == "colorRed") {
        curColor = colorRed;
      }
      else if(color.value == "colorGreen") {
        curColor = colorGreen;
      }
      else if(color.value == "colorYellow") {
        curColor = colorYellow;
      }
      else if(color.value == "colorBlue") {
        curColor = colorBlue;
      }
      else {
        curColor = colorRed;
      }

    }
    color.onchange = function() {
      changeColor();
    };
    clear.onclick = function() {
      clearCanvas();
    };


    //THIS REDRAWS THE PAINT PANEL. DONE AFTER EVERY MOUSE CLICK EVENT.
    //SIMPLY DONE FOR THE CLIENT SIDE CANVAS, i.e. WHAT THE USER SEES.
    function redraw(){
        context.clearRect(0, 0, context.canvas.width, context.canvas.height); // Clears the canvas
        
        
        context.lineJoin = "round";
        context.lineWidth = 5;
                  
        for(var i=0; i < clickX.length; i++) {		
          context.beginPath();
          if(clickDrag[i] && i){
            context.moveTo(clickX[i-1], clickY[i-1]);
          }else{
            context.moveTo(clickX[i]-1, clickY[i]);
          }
          context.lineTo(clickX[i], clickY[i]);
          context.closePath();
          context.strokeStyle = clickColor[i];
          context.stroke();
        }
      }
  
}